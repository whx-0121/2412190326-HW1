"""
Agent核心模块：实现智能体的推理、工具调度和主循环
"""
import time
import dashscope
from dashscope import Generation
from config import DASHSCOPE_API_KEY, MODEL_NAME, MAX_RETRY_TIMES, MAX_HISTORY_LENGTH, TOOL_LIST
from tools import execute_tool

dashscope.api_key = DASHSCOPE_API_KEY


class CodeAgent:
    """
    代码助手Agent类
    封装对话状态和核心行为，符合面向对象设计
    """
    
    def __init__(self):
        # 对话历史（上下文记忆）
        self.history = []
        # 系统提示词：定义Agent身份、工具列表和调用规则
        self.system_prompt = f"""
        你是一个专业的代码助手Agent，你可以调用以下工具来帮助用户：
        {TOOL_LIST}
        
        调用规则：
        1. 根据用户需求，判断需要调用哪个工具，输出固定格式：
           【TOOL:工具名|参数】
           示例：
           - 生成代码：【TOOL:code_generate|写一个冒泡排序函数】
           - 解释代码：【TOOL:code_explain|print("hello world")】
           - 审查代码：【TOOL:code_review|def add(a,b): return a+b】
        2. 只能调用上面列出的三个工具，不要调用不存在的工具。
        3. 如果用户问题和代码无关，直接礼貌说明你只能处理代码相关问题。
        4. 工具执行完成后，我会把结果返回给你，你再整理成自然清晰的回答。
        """
    
    def _call_llm(self, messages):
        """
        内部方法：调用大模型，自带重试机制
        下划线开头表示内部私有方法，不对外暴露，符合封装原则
        """
        for i in range(MAX_RETRY_TIMES):
            try:
                response = Generation.call(
                    model=MODEL_NAME,
                    messages=messages,
                    result_format='message'
                )
                if response.status_code == 200:
                    return response.output.choices[0].message.content
                else:
                    raise Exception(f"API错误码 {response.status_code}")
            except Exception as e:
                # 最后一次重试失败就返回错误
                if i < MAX_RETRY_TIMES - 1:
                    time.sleep(1)  # 等待1秒再重试
                    continue
                return f"调用失败：{str(e)}"
    
    def _trim_history(self):
        """
        内部方法：裁剪对话历史
        边界情况处理：防止对话过长导致token超限
        """
        if len(self.history) > MAX_HISTORY_LENGTH:
            # 保留最近的对话，删掉最早的
            self.history = self.history[-MAX_HISTORY_LENGTH:]
    
    def run(self, user_input):
        """
        执行一次完整的Agent循环
        :param user_input: 用户输入的问题
        :return: 最终回答
        """
        # 边界情况：空输入处理
        if not user_input or not user_input.strip():
            return "请输入有效的代码相关问题~"
        
        # 1. 将用户输入加入对话历史
        self.history.append({"role": "user", "content": user_input})
        # 裁剪历史，避免过长
        self._trim_history()
        
        # 拼接系统提示+对话历史
        messages = [{"role": "system", "content": self.system_prompt}] + self.history
        
        # 2. 第一次推理：判断调用哪个工具
        plan = self._call_llm(messages)
        
        # 3. 判断是否需要调用工具
        if "【TOOL:" in plan and "|" in plan and "】" in plan:
            # 解析工具名称和参数
            start = plan.index("【TOOL:") + len("【TOOL:")
            end = plan.index("】", start)
            tool_part = plan[start:end]
            tool_name, param = tool_part.split("|", 1)
            
            # 边界情况：工具名校验
            if tool_name not in TOOL_LIST:
                return f"抱歉，暂不支持 {tool_name} 工具，我可以帮你生成、解释、审查代码。"
            
            # 4. 调用对应工具
            tool_result = execute_tool(tool_name, param)
            
            # 5. 把工具结果返回给大模型，生成最终自然语言回答
            self.history.append({"role": "assistant", "content": plan})
            self.history.append({"role": "user", "content": f"工具执行结果：\n{tool_result}\n请根据结果整理成清晰的回答"})
            
            messages = [{"role": "system", "content": self.system_prompt}] + self.history
            final_answer = self._call_llm(messages)
            
            self.history.append({"role": "assistant", "content": final_answer})
            return final_answer
        
        else:
            # 不需要调用工具，直接返回回答
            self.history.append({"role": "assistant", "content": plan})
            return plan

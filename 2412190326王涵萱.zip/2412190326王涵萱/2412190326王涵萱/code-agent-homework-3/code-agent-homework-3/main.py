"""
主程序入口：命令行交互界面
"""
from agent import CodeAgent


def main():
    print("=" * 60)
    print("💻 智能代码助手 Agent v3.0 - 软件工程课程作业")
    print("支持功能：代码生成 | 代码解释 | 代码审查")
    print("输入 exit 退出程序")
    print("=" * 60)
    
    # 初始化Agent实例
    agent = CodeAgent()
    
    while True:
        user_input = input("\n👤 请输入你的需求：")
        
        if user_input.lower() == "exit":
            print("👋 感谢使用，程序已退出")
            break
        
        # 运行Agent处理
        print("\n⏳ 正在处理，请稍候...")
        result = agent.run(user_input)
        
        # 输出结果
        print("\n🤖 助手回复：")
        print("-" * 50)
        print(result)
        print("-" * 50)


if __name__ == "__main__":
    main()

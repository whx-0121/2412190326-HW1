"""
配置模块：统一管理项目所有参数
"""

# 大模型配置
DASHSCOPE_API_KEY = "sk-ws-H.PLXXRPE.UzPf.MEUCIH76L6d7KrV0pHBjBkRpRuiGo3kn1cPSi8Mz3dwYZeQ_AiEAwfp9fc_IAqphCwfGtI_b4Lvq5H0MFnHYkEMsNE2CAFw"
MODEL_NAME = "qwen-turbo"

# Agent运行配置
MAX_RETRY_TIMES = 3       # API调用最大重试次数
MAX_HISTORY_LENGTH = 10   # 最大对话历史长度，防止上下文过长

# 工具列表定义
TOOL_LIST = {
    "code_generate": "代码生成工具：根据自然语言描述生成Python代码",
    "code_explain":  "代码解释工具：解释给定代码的逻辑和功能",
    "code_review":   "代码审查工具：检查代码质量，发现问题并给出改进建议"
}

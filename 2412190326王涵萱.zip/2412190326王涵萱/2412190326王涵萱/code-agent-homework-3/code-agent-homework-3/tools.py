"""
工具模块：定义Agent可调用的所有工具函数
"""
import dashscope
from dashscope import Generation
from config import DASHSCOPE_API_KEY, MODEL_NAME

dashscope.api_key = DASHSCOPE_API_KEY


def code_generate(description):
    """
    代码生成工具
    :param description: 自然语言描述的代码需求
    :return: 生成的代码
    """
    prompt = f"""
    请根据以下需求生成规范的Python代码：
    需求：{description}
    要求：
    1. 代码符合PEP8编码规范
    2. 添加清晰的功能注释
    3. 变量命名有实际意义
    4. 只输出代码和注释，不要多余解释文字
    """
    try:
        response = Generation.call(model=MODEL_NAME, prompt=prompt)
        if response.status_code == 200:
            return response.output.text
        else:
            return f"生成失败，错误码：{response.status_code}"
    except Exception as e:
        return f"代码生成工具出错：{str(e)}"


def code_explain(code):
    """
    代码解释工具
    :param code: 需要解释的代码
    :return: 代码解释内容
    """
    prompt = f"""
    请详细解释以下Python代码的逻辑、功能和关键点：
    ```python
    {code}
    ```
    请用通俗的语言分点
    """
    try:
        response = Generation.call(model=MODEL_NAME, prompt=prompt)
        if response.status_code == 200:
            return response.output.text
        else:
            return f"解释失败，错误码：{response.status_code}"
    except Exception as e:
        return f"代码解释工具出错：{str(e)}"


def code_review(code):
    """
    代码审查工具
    :param code: 需要审查的代码
    :return: 审查结果和改进建议
    """
    prompt = f"""
    请对以下 Python 代码进行质量审查：
    ```python
    {code}
    ```
    从以下几个方面分析：

    1. 潜在的 Bug 和逻辑问题
    2. 代码规范问题
    3. 性能优化建议
    4. 可维护性改进建议
    分点清晰说明。
    """
    try:
        response = Generation.call(model=MODEL_NAME, prompt=prompt)
        if response.status_code == 200:
            return response.output.text
        else:
            return f"审查失败，错误码：{response.status_code}"
    except Exception as e:
        return f"代码审查工具出错：{str(e)}"
    
def execute_tool(tool_name, param):
    """
    统一工具调度器
    根据工具名称调用对应的工具函数
    :param tool_name: 工具名称
    :param param: 工具入参
    :return: 工具执行结果
    """
    tool_map = {
    "code_generate": code_generate,
    "code_explain": code_explain,
    "code_review": code_review
    }

    if tool_name not in tool_map:
        return f"错误：未知工具 {tool_name}"

    return tool_map[tool_name](param)